import 'package:flutter/material.dart';

class colors {
  static int index = 0;
  static Color getPrimary(i) {
    switch (i) {
      case 0:
        return Colors.green;
      case 1:
        return Colors.yellow;
      case 2:
        return Colors.blue;
    }
    return Colors.white;
  }

  static Color getCanvas(i) {
    switch (i) {
      case 0:
        return Colors.green.shade100;
      case 1:
        return Colors.yellow.shade100;
      case 2:
        return Colors.blue.shade100;
    }
    return Colors.white;
  }

  static Color getAccent(i) {
    switch (i) {
      case 0:
        return Colors.lightGreen;
      case 1:
        return Colors.yellow.shade700;
      case 2:
        return Colors.lightBlue;
    }
    return Colors.white;
  }
}
