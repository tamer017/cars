import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Car {
  final String id;
  final String model;
  final int price;
  final int cc;
  final int speed;
  final int tank;
  final int year;
  final String description;
  String favoriteId;
  static List<Car> favCars = [];
  Car(
      {required this.id,
      required this.model,
      required this.price,
      required this.cc,
      required this.speed,
      required this.tank,
      required this.year,
      required this.description,
      this.favoriteId = ""});

  static String encoder(List<Car> cars) {
    return json.encode(
        cars.map<Map<String, dynamic>>((car) => Car.toMap(car)).toList());
  }

  static List<Car> decoder(String cars) => (json.decode(cars) as List<dynamic>)
      .map<Car>((car) => Car.fromMap(car))
      .toList();

  static Map<String, dynamic> toMap(car) {
    return {
      "id": car.id,
      "model": car.model,
      "price": car.price,
      "cc": car.cc,
      "speed": car.speed,
      "tank": car.tank,
      "year": car.year,
      "description": car.description
    };
  }

  static Car fromMap(Map<String, dynamic> map) {
    return Car(
        id: map["id"],
        model: map["model"],
        price: map["price"],
        cc: map["cc"],
        speed: map["speed"],
        tank: map["tank"],
        year: map["year"],
        description: map["description"]);
  }

  static Future<String> getCars() async {
    final pref = await SharedPreferences.getInstance();
    final data = pref.getString("favorite_cars");
    if (data == null)
      return "";
    else {
      if (data != "") {
        favCars = Car.decoder(data);
      }
      return data;
    }
  }

  static Future<void> addCar(Car car) async {
    final prefs = await SharedPreferences.getInstance();

    await Car.getCars();

    favCars.add(car);

    await prefs.setString("favorite_cars", Car.encoder(favCars));
  }

  static Future<void> deleteCar({required id}) async {
    final prefs = await SharedPreferences.getInstance();

    await Car.getCars();
    if (favCars.length == 0)
      return;
    else {
      int index = -1;
      favCars.forEach((element) {
        if (element.id == id) {
          index = favCars.indexOf(element);
        }
      });
      if (index != -1) favCars.removeAt(index);
      await prefs.setString("favorite_cars", Car.encoder(favCars));
    }
  }

  static Future<void> deleteAll() async {
    final prefs = await SharedPreferences.getInstance();
    favCars = [];
    await prefs.setString("favorite_cars", "");
  }
}
