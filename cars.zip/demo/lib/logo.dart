import 'package:flutter/material.dart';

class Logo extends StatelessWidget {
  final String imageUrl;
  final double radius;
  final double index;

  const Logo(
      {required this.imageUrl, required this.radius, required this.index});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(radius / 5),
      child: GestureDetector(
        onTap: () {},
        child: CircleAvatar(
          backgroundColor: Colors.white,
          radius: radius,
          child: Image.network(
            imageUrl,
            fit: BoxFit.fill,
          ),
        ),
      ),
    );
  }
}
