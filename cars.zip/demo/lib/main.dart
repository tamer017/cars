import 'package:demo/colors.dart';
import 'package:demo/providers/auth.dart';
import 'package:demo/screens/auth_screen.dart';
import 'package:demo/screens/home_screen.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/cars.dart';

void main() {
  runApp(MyApp());
}

int index = 0;

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<Cars>(
          create: (context) => Cars(),
        ),
        ChangeNotifierProvider<Auth>(
          create: (context) => Auth(),
        ),
      ],
      child: Builder(
        builder: (context) => MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            primaryColor: colors.getPrimary(context.watch<Cars>().theme),
            canvasColor: colors.getCanvas(context.watch<Cars>().theme),
            accentColor: colors.getAccent(context.watch<Cars>().theme),
          ),
          home: HomeScreen(),
        ),
      ),
    );
  }
}
