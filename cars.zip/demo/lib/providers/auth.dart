import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';

class Auth extends ChangeNotifier {
  Future<void> authentication(
      String email, String password, String urlSegment) async {
    String url =
        "https://identitytoolkit.googleapis.com/v1/accounts:$urlSegment?key=AIzaSyAbZRsQZTJkkChVD08Fyf2eWLJMKbH__8o";
    try {
      var res = await http.post(Uri.parse(url),
          body: json.encode({
            "email": email,
            "password": password,
            "returnSecureToken": true
          }));
      if (json.decode(res.body)["error"] != null)
        throw json.decode(res.body)["error"]["message"];
    } on Exception catch (e) {
      throw e;
    }
  }

  Future<void> signUp(String email, String password) async {
    return await authentication(email, password, "signUp");
  }

  Future<void> signIn(String email, String password) async {
    return await authentication(email, password, "signInWithPassword");
  }
}
