import 'dart:convert';

import 'package:demo/colors.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../local_storge.dart';

class IdIndex {
  final int index;
  final String id;

  const IdIndex({required this.index, required this.id});
}

class Cars with ChangeNotifier {
  List<IdIndex> selectedCar = [];
  List<IdIndex> selectedFavoriteCar = [];
  List<Car> filtered = [];
  bool searching = false;

  filter(text) {
    if (text.length > 0) {
      searching = true;
      filtered = [];
      cars.forEach((car) {
        if (car.model.toString().toLowerCase().contains(text.toLowerCase())) {
          filtered.add(car);
        }
      });
    } else {
      searching = false;
      filtered = cars;
    }
    notifyListeners();
  }

  List<Car> cars = [];
  List<Car> favoriteCars = [];
  bool isSelected = false;
  bool isSelectedfav = false;
  int theme = 0;
  setTheme(value) {
    colors.index = value;
    theme = value;
    notifyListeners();
  }

  setFavlist(car) {
    favoriteCars.add(car);
    notifyListeners();
  }

  select(bool state) {
    isSelected = state;
    notifyListeners();
  }

  selectfav(bool state) {
    isSelectedfav = state;
    notifyListeners();
  }

  cencel() {
    selectedCar = [];
    notifyListeners();
  }

  addIndex(index) {
    if (!containIndex(index))
      selectedCar.add(IdIndex(index: index, id: filtered.elementAt(index).id));
    notifyListeners();
  }

  deleteIndex(index) {
    selectedCar.removeWhere((element) => element.index == index);
    notifyListeners();
  }

  bool containIndex(index) {
// ignore: unnecessary_null_comparison
    for (int i = 0; i < selectedCar.length; i++) {
      if (selectedCar[i].index == index) return true;
    }
    return false;
  }

  // addFav(id) {
  //   if (!containFav(id)) {
  //     favoriteCars
  //         .add(IdIndex(index: index, id: cars.elementAt(index).id));
  //   }
  //   notifyListeners();
  // }

  deleteFav(car) {
    favoriteCars =
        favoriteCars.where((element) => element.id != car.id).toList();

    Car.deleteCar(id: car.id);
    notifyListeners();
  }

  bool containFav(id) {
// ignore: unnecessary_null_comparison
    for (int i = 0; i < favoriteCars.length; i++) {
      if (favoriteCars[i].id == id) return true;
    }
    return false;
  }

  delete() {
    selectedCar.forEach((car) {
      http.delete(Uri.parse(
          "https://products-e42d3-default-rtdb.firebaseio.com/cars/${car.id}.json"));
      filtered.removeWhere((element) => element.id == car.id);
      cars.removeWhere((element) => element.id == car.id);
      favoriteCars.forEach((element) {});
      if (containFav(car.id)) {
        deleteFav(car);
      }
      favoriteCars.forEach((element) {});
    });
    selectedCar = [];
    isSelected = false;
    notifyListeners();
  }

  Future<void> fetch() async {
    await http
        .get(
      Uri.parse("https://products-e42d3-default-rtdb.firebaseio.com/cars.json"),
    )
        .then((value) {
      try {
        var a = json.decode(value.body) as Map<String, dynamic>;
        cars = [];
        filtered = [];
        a.forEach((key, value) {
          // Car x = cars.firstWhere((element) {
          //   return value["id"] == element0id;
          // }, orElse: null);
          // // ignore: unnecessary_null_comparison
          // if (x == null) {
          cars.add(Car(
              id: key,
              model: value["model"],
              price: value["price"],
              cc: value["cc"],
              speed: value["speed"],
              tank: value["tank"],
              year: value["year"],
              description: value["description"]));
          filtered.add(Car(
              id: key,
              model: value["model"],
              price: value["price"],
              cc: value["cc"],
              speed: value["speed"],
              tank: value["tank"],
              year: value["year"],
              description: value["description"]));
          notifyListeners(); // }
        });
      } // ignore: non_constant_identifier_names
      catch (error) {
        cars = [];
        filtered = [];
        notifyListeners();
      }
    }).catchError((error) => throw error);
  }

  Future<void> add(
      {required id,
      required model,
      required price,
      required cc,
      required speed,
      required tank,
      required year,
      required description}) async {
    await http
        .post(
      Uri.parse("https://products-e42d3-default-rtdb.firebaseio.com/cars.json"),
      body: json.encode(
        {
          "id": id,
          "model": model,
          "price": price,
          "description": description,
          "year": year,
          "tank": tank,
          "speed": speed,
          "cc": cc,
        },
      ),
    )
        .then(
      (value) {
        cars.add(
          new Car(
            id: json.decode(value.body)["name"],
            model: model,
            price: price,
            cc: cc,
            speed: speed,
            tank: tank,
            year: year,
            description: description,
          ),
        );
        filtered.add(
          new Car(
            id: json.decode(value.body)["name"],
            model: model,
            price: price,
            cc: cc,
            speed: speed,
            tank: tank,
            year: year,
            description: description,
          ),
        );
        notifyListeners();
      },
    ).catchError(
      (error) {
        throw error;
      },
    );
  }

  Future<void> getFromApi() async {
    await http
        .get(
      Uri.parse(
          "https://private-anon-ed583862d6-carsapi1.apiary-mock.com/cars"),
    )
        .then((value) {
      try {
        List<dynamic> a = json.decode(value.body);
        print(a);
        
        http.post(
          Uri.parse(
              "https://products-e42d3-default-rtdb.firebaseio.com/cars.json"),
          body: json.encode(a),
        );
      } catch (error) {
        print(error);
      }
    }).catchError((error) => throw error);
  }
}
