import 'package:demo/providers/cars.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddCar extends StatelessWidget {
  const AddCar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return NewCar();
  }
}

class NewCar extends StatefulWidget {
  @override
  _NewCarState createState() => _NewCarState();
}

class _NewCarState extends State<NewCar> {
  TextEditingController modelController = TextEditingController();

  TextEditingController tankController = TextEditingController();

  TextEditingController yearController = TextEditingController();

  TextEditingController priceController = TextEditingController();

  TextEditingController ccController = TextEditingController();

  TextEditingController descriptionController = TextEditingController();

  TextEditingController maxspeedController = TextEditingController();

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    double heightBlock = MediaQuery.of(context).size.height / 100;
    double widthBlock = MediaQuery.of(context).size.width / 100;
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Car'),
      ),
      body: Form(
        key: formKey,
        child: Container(
          height: 100 * heightBlock,
          color: Theme.of(context).canvasColor,
          padding: EdgeInsets.symmetric(
              horizontal: widthBlock * 2.5, vertical: heightBlock * 3),
          child: ListView(
            children: [
              TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  prefixIcon: const Icon(Icons.car_repair),
                  hintText: "enter your car model",
                  labelText: "model",
                  helperText: "car model",
                ),
                controller: modelController,
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return "please type your car model";
                  return null;
                },
                keyboardType: TextInputType.text,
              ),
              SizedBox(
                height: heightBlock * 2,
              ),
              TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  prefixIcon: const Icon(Icons.monetization_on_rounded),
                  hintText: "enter your car price",
                  labelText: "price",
                  helperText: "car price",
                ),
                controller: priceController,
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return "please type your car price";
                  else {
                    try {
                      double.parse(value);
                      return null;
                    } catch (error) {
                      return "please enter valid car price";
                    }
                  }
                },
                keyboardType: TextInputType.number,
              ),
              SizedBox(
                height: heightBlock * 2,
              ),
              TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  prefixIcon: const Icon(Icons.description),
                  hintText: "enter your car description",
                  labelText: "description",
                  helperText: "description",
                ),
                controller: descriptionController,
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return "please type your car description";
                  return null;
                },
                keyboardType: TextInputType.text,
              ),
              SizedBox(
                height: heightBlock * 2,
              ),
              TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  prefixIcon: const Icon(Icons.running_with_errors),
                  hintText: "enter your car tank capacity",
                  labelText: "tank capacity",
                  helperText: "car tank capacity",
                ),
                controller: tankController,
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return "please type your car tank capacity";
                  else {
                    try {
                      double.parse(value);
                      return null;
                    } catch (error) {
                      return "please enter valid tank capacity";
                    }
                  }
                },
                keyboardType: TextInputType.number,
              ),
              SizedBox(
                height: heightBlock * 2,
              ),
              TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  prefixIcon: const Icon(Icons.power),
                  hintText: "enter your car car cc",
                  labelText: "cc",
                  helperText: "car cc",
                ),
                controller: ccController,
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return "please type your car cc";
                  else {
                    try {
                      double.parse(value);
                      return null;
                    } catch (error) {
                      return "please enter valid car cc";
                    }
                  }
                },
                keyboardType: TextInputType.number,
              ),
              SizedBox(
                height: heightBlock * 2,
              ),
              TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  prefixIcon: const Icon(Icons.run_circle_outlined),
                  hintText: "enter your car maximum speed",
                  labelText: "maximum speed",
                  helperText: "maximum speed",
                ),
                controller: maxspeedController,
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return "please type your maximum speed";
                  else {
                    try {
                      double.parse(value);
                      return null;
                    } catch (error) {
                      return "please enter valid speed";
                    }
                  }
                },
                keyboardType: TextInputType.number,
              ),
              SizedBox(
                height: heightBlock * 2,
              ),
              TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  prefixIcon: const Icon(Icons.run_circle_outlined),
                  hintText: "enter your car production year",
                  labelText: "year",
                  helperText: "car production year",
                ),
                controller: yearController,
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return "please type your  car production year";
                  else {
                    try {
                      double.parse(value);
                      return null;
                    } catch (error) {
                      return "please enter valid year";
                    }
                  }
                },
                keyboardType: TextInputType.datetime,
              ),
              SizedBox(
                height: heightBlock * 2,
              ),
              OutlinedButton(
                onPressed: () {
                  // setState((){
                  // if (formKey.currentState!.validate()) {
                  context
                      .read<Cars>()
                      .add(
                          id: DateTime.now().toString(),
                          model: "model",
                          price: 70000,
                          cc: 3000,
                          speed: 300,
                          tank: 80,
                          year: 2022,
                          description: "description")
                      .catchError(
                    (err) {
                      return showDialog<Null>(
                          context: context,
                          builder: (ctx) {
                            return AlertDialog(
                              backgroundColor: Theme.of(ctx).primaryColor,
                              title: Container(
                                child: Text(
                                  "error",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    color: Colors.red,
                                    fontSize: heightBlock * 3,
                                  ),
                                ),
                              ),
                              content: Container(
                                width: double.infinity,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      Icons.error_outline_rounded,
                                      color: Colors.red,
                                      size: heightBlock * 15,
                                    ),
                                    Text(
                                      "something went wrong",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white,
                                        fontSize: heightBlock * 2,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              actions: [
                                TextButton(
                                    onPressed: () {
                                      Navigator.of(ctx).pop();
                                    },
                                    child: Text(
                                      "ok",
                                      style: TextStyle(
                                        fontSize: heightBlock * 1.5,
                                        color: Colors.white,
                                      ),
                                    ))
                              ],
                            );
                          });
                    },
                  ).then(
                    (value) {
                      Navigator.of(context).pop();
                    },
                  );
                  // }

                  // });
                },
                child: Container(
                  alignment: Alignment.center,
                  height: heightBlock * 7.5,
                  child: const Text(
                    "add car",
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                ),
                style: OutlinedButton.styleFrom(
                  backgroundColor: Theme.of(context).primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              SizedBox(
                height: heightBlock * 4,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
