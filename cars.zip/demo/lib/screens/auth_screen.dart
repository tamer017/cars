import 'package:demo/providers/auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'home_screen.dart';

class AuthScreen extends StatefulWidget {
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  TextEditingController confirmPasswordController = TextEditingController();

  bool authMode = true;

  @override
  Widget build(BuildContext context) {
    double heightBlock = MediaQuery.of(context).size.height / 100;
    double widthBlock = MediaQuery.of(context).size.width / 100;
    return ChangeNotifierProvider(
      create: (_) => Auth(),
      child: Scaffold(
        body: Container(
          alignment: Alignment.center,
          color: Colors.blue.shade100.withOpacity(0.8),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: heightBlock * 80,
              ),
              Positioned(
                top: heightBlock * 10,
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)),
                  elevation: 20,
                  color: Colors.amber,
                  child: Container(
                    height: authMode ? 60 * heightBlock : 50 * heightBlock,
                    width: 80 * widthBlock,
                    alignment: Alignment.center,
                    padding: EdgeInsets.symmetric(
                        vertical: 2 * heightBlock, horizontal: 10 * widthBlock),
                    child: Form(
                        child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextFormField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            prefixIcon: const Icon(Icons.email),
                            hintText: "enter your email",
                            labelText: "email",
                            helperText: "email accont",
                            helperStyle: TextStyle(
                              color: Colors.blue,
                            ),
                            fillColor: Theme.of(context).primaryColor,
                            focusColor: Theme.of(context).primaryColor,
                            hoverColor: Theme.of(context).primaryColor,
                          ),
                          controller: emailController,
                          validator: (value) {
                            if (value == null || value.isEmpty)
                              return "please type your maximum speed";
                            else {
                              try {
                                double.parse(value);
                                return null;
                              } catch (error) {
                                return "please enter valid speed";
                              }
                            }
                          },
                          keyboardType: TextInputType.emailAddress,
                        ),
                        SizedBox(
                          height: heightBlock * 1,
                        ),
                        TextFormField(
                          obscureText: true,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            prefixIcon: const Icon(Icons.vpn_key),
                            hintText: "enter your password",
                            helperStyle: TextStyle(
                              color: Colors.blue,
                            ),
                            labelText: "password",
                            helperText: "email password",
                          ),
                          controller: passwordController,
                          validator: (value) {
                            if (value == null || value.isEmpty)
                              return "please type your  car production year";
                            else {
                              try {
                                double.parse(value);
                                return null;
                              } catch (error) {
                                return "please enter valid year";
                              }
                            }
                          },
                          keyboardType: TextInputType.visiblePassword,
                        ),
                        SizedBox(
                          height: heightBlock * 1,
                        ),
                        authMode
                            ? TextFormField(
                                obscureText: true,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  prefixIcon: const Icon(Icons.vpn_key),
                                  hintText: "please confirm your password",
                                  labelText: "confirm password",
                                  helperText: "confirm your password",
                                  helperStyle: TextStyle(
                                    color: Colors.blue,
                                  ),
                                ),
                                controller: confirmPasswordController,
                                validator: (value) {
                                  if (value == null || value.isEmpty)
                                    return "please type your  car production year";
                                  else {
                                    try {
                                      double.parse(value);
                                      return null;
                                    } catch (error) {
                                      return "please enter valid year";
                                    }
                                  }
                                },
                                keyboardType: TextInputType.visiblePassword,
                              )
                            : SizedBox(),
                        SizedBox(
                          height: heightBlock * 1,
                        ),
                        Container(
                          padding:
                              EdgeInsets.symmetric(horizontal: widthBlock * 5),
                          child: OutlinedButton(
                            onPressed: () async {
                              // setState((){
                              // if (formKey.currentState!.validate()) {
                              try {
                                if (authMode)
                                  await context
                                      .read<Auth>()
                                      .signUp('email@google.com', "password");
                                else
                                  await context
                                      .read<Auth>()
                                      .signIn('email@google.com', "password");
                                Navigator.push(context,
                                    MaterialPageRoute(builder: (context) {
                                  return HomeScreen();
                                }));
                              } catch (e) {
                                String error_message = "";
                                if (e.toString().contains("EMAIL_EXISTS"))
                                  error_message = 'this email is already used ';
                                else if (e.toString().contains("INVALID_EMAIL"))
                                  error_message =
                                      'this is not valid email address';
                                else if (e.toString().contains("WEAK_PASSWORD"))
                                  error_message = 'this password is too weak';
                                else if (e
                                    .toString()
                                    .contains("EMAIL_NOT_FOUND"))
                                  error_message =
                                      'can not find user with that email';
                                else if (e
                                    .toString()
                                    .contains("INVALID_PASSWORD"))
                                  error_message = 'invalid password';
                                buildShowDialog(context, error_message);
                              }
                            },
                            child: Container(
                              alignment: Alignment.center,
                              child: Text(
                                authMode ? "sign in" : "log in",
                                style: TextStyle(
                                    color: Colors.amber,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w700),
                              ),
                            ),
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            setState(() {
                              authMode = !authMode;
                            });
                          },
                          child: Text(
                            "${!authMode ? "sign in" : "log in"} insteade",
                            style: TextStyle(
                                color: Colors.blue,
                                fontSize: 15,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ],
                    )),
                  ),
                ),
              ),
              Positioned(
                child: Container(
                  height: 8 * heightBlock,
                  width: 25 * widthBlock,
                  child: Image.asset(
                    "assets/car.png",
                    fit: BoxFit.fill,
                  ),
                ),
                top: 3 * heightBlock,
                left: 20 * widthBlock,
              ),
            ],
          ),
        ),
      ),
    );
  }

  buildShowDialog(context, text) {
    showDialog(
      context: context,
      builder: (context) {
        double heightBlock = MediaQuery.of(context).size.height / 100;
        double widthBlock = MediaQuery.of(context).size.width / 100;
        return AlertDialog(
          backgroundColor: Colors.blue.shade100.withOpacity(0.9),
          title: Text(
            "error",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.w900,
              color: Colors.black,
              fontSize: heightBlock * 3,
            ),
          ),
          content: Container(
            width: double.infinity,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  text,
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                    fontSize: heightBlock * 2,
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text(
                  "ok",
                  style: TextStyle(
                    fontSize: heightBlock * 1.5,
                    color: Colors.black,
                  ),
                ))
          ],
        );
      },
    );
  }
}
