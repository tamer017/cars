import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cars.dart';

class CarCard extends StatelessWidget {
  final String name;
  final String price;
  final int index;
  final Color color;
  final bool isFavorite;
  const CarCard(
      {required this.name,
      required this.price,
      required this.index,
      required this.color,
      required this.isFavorite});

  @override
  Widget build(BuildContext context) {
    double heightBlock = MediaQuery.of(context).size.height / 100;

    return ChangeNotifierProvider<Cars>(
      create: (_) => Cars(),
      child: Container(
        margin: EdgeInsets.only(
          left: 0,
          right: 0,
          top: index.isEven ? 0 : heightBlock * 2.5,
          bottom: index.isOdd ? 0 : heightBlock * 2.5,
        ),
        child: Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          color: color,
          child: Column(
            children: [
              Expanded(
                child: ClipRRect(
                  child: Image.network(
                    "https://ymimg1.b8cdn.com/resized/car_model/6299/logo/mobile_listing_main_01.png",
                    fit: BoxFit.fill,
                  ),
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20)),
                ),
                flex: 4,
              ),
              Expanded(
                flex: 2,
                child: ListTile(
                    title: Text(
                      name,
                    ),
                    subtitle: RichText(
                      text: TextSpan(
                        children: [
                          const TextSpan(
                            text: 'Price ',
                          ),
                          TextSpan(
                            text: '$price\$',
                          ),
                        ],
                      ),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        isFavorite
                            ? Icon(
                                Icons.favorite,
                                color: Colors.white,
                                size: heightBlock * 2.5,
                              )
                            : const Text(""),
                        const Icon(
                          Icons.more_vert_outlined,
                          color: Colors.white,
                        ),
                      ],
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
