import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class CarInfo extends StatefulWidget {
  @override
  _CarInfoState createState() => _CarInfoState();
}

class _CarInfoState extends State<CarInfo> {
  int index = 0;
  List<String> Images = [
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwJTlJYsK1u_rpki8zbF-KKG8hwV7KiJwicA&usqp=CAU",
    "https://ymimg1.b8cdn.com/resized/car_model/6299/pictures/6205848/mobile_listing_main_2019_Audi_Q8__5_.jpg",
    "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/2019-audi-q8-361-1544802623.jpg?crop=0.678xw:0.572xh;0.322xw,0.373xh&resize=1200:*",
  ];

  @override
  Widget build(BuildContext context) {
    double heightBlock = MediaQuery.of(context).size.height / 100;
    double widthBlock = MediaQuery.of(context).size.width / 100;
    return Scaffold(
      appBar: AppBar(
        title: Text('Audi Q8'),
      ),
      body: Container(
        margin: EdgeInsets.symmetric(
          horizontal: widthBlock * 2.5,
          vertical: heightBlock * 2.5,
        ),
        child: ListView(
          padding: EdgeInsets.symmetric(
            vertical: 0,
          ),
          children: [
            Stack(
              children: [
                Container(
                  height: heightBlock * 80,
                ),
                CarouselSlider(
                  items: Images.map((image) {
                    return Container(
                      height: heightBlock * 50,
                      width: double.infinity,
                      // margin: EdgeInsets.symmetric(horizontal: widthBlock * 1),
                      child: Stack(
                        children: [
                          Image.network(
                            image,
                            fit: BoxFit.fill,
                            height: heightBlock * 30,
                            width: double.infinity,
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                  options: CarouselOptions(
                      autoPlay: true,
                      autoPlayInterval: Duration(seconds: 5),
                      height: heightBlock * 30,
                      enlargeCenterPage: true,
                      initialPage: index),
                ),
                Positioned(
                  right: widthBlock * 12,
                  top: heightBlock * 20,
                  child: Text(
                    'Audi Q8',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.6),
                        fontSize: heightBlock * 5,
                        backgroundColor: Colors.green.withOpacity(0.4),
                        fontWeight: FontWeight.w600),
                  ),
                ),
                Positioned(
                  left: widthBlock * 12,
                  top: heightBlock * 1,
                  child: Text(
                    '2022',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.6),
                        fontSize: heightBlock * 4,
                        backgroundColor: Colors.green.withOpacity(0.4),
                        fontWeight: FontWeight.w600),
                  ),
                ),
                Positioned(
                  top: heightBlock * 28,
                  left: widthBlock * 5,
                  right: widthBlock * 5,
                  child: Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: widthBlock * 2, vertical: heightBlock * 3),
                    decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                              blurRadius: 0.1,
                              spreadRadius: 0.1,
                              offset: Offset(0, -1))
                        ],
                        borderRadius: BorderRadius.circular(30)
                        /* (
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                        ) */
                        ,
                        color: Colors.white),
                    child: Column(
                      children: [
                        Expanded(
                          child: SingleChildScrollView(
                            child: Text(
                              '''With dramatic proportions and only two rows of seats, the 2022 Audi Q8 is the company's flagship SUV, a flashier alternative to the three-row Q7. The two Audis share a platform and a 335-hp V-6 powertrain, but the Q8's shorter length and sportier roofline reduce back-seat headspace and shrink the cargo area. While those compromises hurt its practicality quotient, the Q8 still has a spacious interior that's classy and cutting edge. The dash's digital parts look slick and pack desirable tech features, but the lowermost touchscreen can divert the driver's attention. At least the Q8 is fun to drive; following the precedent established by other crossover 'coupes,' it provides high-riding capability with lively driving responses. The 2022 Q8 is considerably more expensive than the Q7, with a price that starts about 13,000 higher—but that's the price of fashion.//////////////With dramatic proportions and only two rows of seats, the 2022 Audi Q8 is the company's flagship SUV, a flashier alternative to the three-row Q7. The two Audis share a platform and a 335-hp V-6 powertrain, but the Q8's shorter length and sportier roofline reduce back-seat headspace and shrink the cargo area. While those compromises hurt its practicality quotient, the Q8 still has a spacious interior that's classy and cutting edge. The dash's digital parts look slick and pack desirable tech features, but the lowermost touchscreen can divert the driver's attention. At least the Q8 is fun to drive; following the precedent established by other crossover 'coupes,' it provides high-riding capability with lively driving responses. The 2022 Q8 is considerably more expensive than the Q7, with a price that starts about 13,000 higher—but that's the price of fashion.''',
                              style: TextStyle(fontSize: heightBlock * 1.7),
                              textAlign: TextAlign.justify,
                              overflow: TextOverflow.fade,
                            ),
                          ),
                        ),
                        Container(
                          margin:
                              EdgeInsets.symmetric(vertical: heightBlock * 2.5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              CircleAvatar(
                                radius: widthBlock * 10,
                                backgroundColor: Theme.of(context).primaryColor,
                                child: Text(
                                  "300 km/h",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).canvasColor,
                                      fontSize: heightBlock * 1.7),
                                ),
                              ),
                              CircleAvatar(
                                radius: widthBlock * 10,
                                backgroundColor: Theme.of(context).primaryColor,
                                child: Text(
                                  "3000 cc",
                                  style: TextStyle(
                                      color: Theme.of(context).canvasColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: heightBlock * 1.7),
                                ),
                              ),
                              CircleAvatar(
                                radius: widthBlock * 10,
                                backgroundColor: Theme.of(context).primaryColor,
                                child: Text(
                                  "70 Liter",
                                  style: TextStyle(
                                      color: Theme.of(context).canvasColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: heightBlock * 1.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    height: heightBlock * 50,
                    // color: Colors.red,
                  ),
                ),
              ],
            ),
            Container(
              padding: EdgeInsets.all(widthBlock * 1),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.amber,
              ),
              margin: EdgeInsets.symmetric(
                  vertical: heightBlock * 2, horizontal: widthBlock * 15),
              width: double.infinity,
              child: ListTile(
                trailing: Icon(
                  Icons.monetization_on,
                  size: heightBlock * 4,
                  color: Colors.red,
                ),
                title: Text(
                  "70,000",
                  style: TextStyle(
                      fontSize: heightBlock * 4,
                      fontWeight: FontWeight.w600,
                      color: Colors.red),
                ),
                leading: Text(
                  "price:",
                  style: TextStyle(
                      fontSize: heightBlock * 3, fontWeight: FontWeight.w300),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
