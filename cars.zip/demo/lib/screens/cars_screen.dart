import 'package:demo/logos_urls.dart';
import 'package:demo/providers/cars.dart';
import 'package:demo/logo.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'car_card.dart';
import 'car_info.dart';
import '../local_storge.dart';

class CarsScreen extends StatefulWidget {
  CarsScreen();
  @override
  _CarsScreenState createState() => _CarsScreenState();
}

class _CarsScreenState extends State<CarsScreen> {
  bool isLoading = true;
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    searchController.addListener(() => onSearchChange(context));
    context.read<Cars>().fetch().catchError(
      (err) {
        return showDialog<Null>(
            context: context,
            builder: (ctx) {
              double heightBlock = MediaQuery.of(context).size.height / 100;
              return AlertDialog(
                backgroundColor: Theme.of(ctx).primaryColor,
                title: Container(
                  child: Text(
                    "error",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: Colors.red,
                      fontSize: heightBlock * 3,
                    ),
                  ),
                ),
                content: Container(
                  width: double.infinity,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.error_outline_rounded,
                        color: Colors.red,
                        size: heightBlock * 15,
                      ),
                      Text(
                        "something went wrong ${err.toString()}",
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                          fontSize: heightBlock * 2,
                        ),
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                      onPressed: () {
                        setState(() {
                          isLoading = false;
                        });
                        Navigator.of(ctx).pop();
                      },
                      child: Text(
                        "ok",
                        style: TextStyle(
                          fontSize: heightBlock * 1.5,
                          color: Colors.white,
                        ),
                      ))
                ],
              );
            });
      },
    ).then((value) => setState(() {
          isLoading = false;
        }));
    super.initState();
  }

  bool searching = false;
  @override
  Widget build(BuildContext context) {
    double heightBlock = MediaQuery.of(context).size.height / 100;
    double widthBlock = MediaQuery.of(context).size.width / 100;
    return ChangeNotifierProvider<Cars>(
      create: (_) => Cars(),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(
                  top: 1 * heightBlock,
                  left: 1 * widthBlock,
                  right: 1 * widthBlock,
                  bottom: heightBlock),
              child: Card(
                child: ListTile(
                  leading: const Icon(Icons.search),
                  title: TextField(
                    keyboardType: TextInputType.text,
                    controller: searchController,
                    decoration: const InputDecoration(
                        hintText: 'Search', border: InputBorder.none),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.cancel),
                    onPressed: () {
                      searchController.clear();
                      setState(() {
                        context.read<Cars>().filtered =
                            context.read<Cars>().cars;
                      });
                    },
                  ),
                ),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.all(1 * heightBlock),
              child: Row(
                children: LogosUrl.imageUrls
                    .map(
                      (url) => Logo(
                        imageUrl: url,
                        radius: 5 * heightBlock,
                        index: LogosUrl.imageUrls.indexOf(url).toDouble(),
                      ),
                    )
                    .toList(),
              ),
            ),
            context.watch<Cars>().isSelected && !isLoading
                ? Container(
                    color: Theme.of(context).primaryColor.withOpacity(0.3),
                    height: heightBlock * 7.5,
                    child: Row(
                      children: [
                        Expanded(
                          flex: 5,
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: widthBlock * 2),
                            child: Text(
                                "${context.read<Cars>().selectedCar.length} ${context.read<Cars>().selectedCar.length == 1 ? 'car is' : 'cars are'} selected"),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: GestureDetector(
                            child: const Icon(
                              Icons.delete,
                              color: Colors.red,
                            ),
                            onTap: () {
                              context.read<Cars>().delete();
                            },
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: GestureDetector(
                            child: const Icon(
                              Icons.cancel,
                              color: Colors.green,
                            ),
                            onTap: () {
                              context.read<Cars>().cencel();
                              context.read<Cars>().select(false);
                            },
                          ),
                        ),
                      ],
                    ),
                  )
                : Container(),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 2 * widthBlock),
              height: context.watch<Cars>().isSelected
                  ? heightBlock * 80
                  : heightBlock * 87.5,
              child: isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                        strokeWidth: 5,
                        color: Theme.of(context).primaryColor,
                      ),
                    )
                  : context.read<Cars>().filtered.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "No Cars to show",
                                style: TextStyle(
                                    color: Theme.of(context).primaryColor,
                                    fontSize: heightBlock * 5,
                                    fontWeight: FontWeight.w900),
                              ),
                              TextButton.icon(
                                onPressed: () {
                                  setState(() {});
                                },
                                icon: Icon(Icons.replay_outlined,
                                    color: Theme.of(context).primaryColor),
                                label: Text(
                                  "click  here to refresh",
                                  style: TextStyle(
                                      color: Theme.of(context).primaryColor),
                                ),
                              ),
                            ],
                          ),
                        )
                      : RefreshIndicator(
                          onRefresh: () async {
                            await context.read<Cars>().fetch().then(
                                  (value) => setState(() {}),
                                );
                          },
                          child: GridView(
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              mainAxisExtent: heightBlock * 35,
                              crossAxisSpacing: 0,
                              mainAxisSpacing: 0,
                            ),
                            children: context
                                .watch<Cars>()
                                .filtered
                                .map(
                                  (car) => GestureDetector(
                                    onLongPress: () {
                                      context.read<Cars>().select(true);
                                      context.read<Cars>().addIndex(context
                                          .read<Cars>()
                                          .filtered
                                          .indexOf(car));
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(
                                        left: 0,
                                        right: 0,
                                        top: context
                                                .read<Cars>()
                                                .filtered
                                                .indexOf(car)
                                                .isEven
                                            ? 0
                                            : heightBlock * 2.5,
                                        bottom: context
                                                .read<Cars>()
                                                .filtered
                                                .indexOf(car)
                                                .isOdd
                                            ? 0
                                            : heightBlock * 2.5,
                                      ),
                                      child: CarCard(
                                          name: car.model,
                                          price: car.price.toString(),
                                          index: context
                                              .read<Cars>()
                                              .filtered
                                              .indexOf(car),
                                          color: context
                                                      .watch<Cars>()
                                                      .isSelected &&
                                                  context
                                                      .read<Cars>()
                                                      .containIndex(context
                                                          .read<Cars>()
                                                          .filtered
                                                          .indexOf(car))
                                              ? Colors.red
                                              : Theme.of(context).primaryColor,
                                          isFavorite: context
                                              .read<Cars>()
                                              .containFav(car.id)),
                                    ),
                                    onTap: () {
                                      if (context.read<Cars>().isSelected) {
                                        context.read<Cars>().deleteIndex(context
                                            .read<Cars>()
                                            .filtered
                                            .indexOf(car));
                                        if (context
                                                .read<Cars>()
                                                .selectedCar
                                                .length ==
                                            0)
                                          context.read<Cars>().select(false);
                                      } else
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (ctx) => CarInfo()));
                                    },
                                    onDoubleTap: () {
                                      if (!context
                                          .read<Cars>()
                                          .containFav(car.id)) {
                                        Car.addCar(car);

                                        context.read<Cars>().setFavlist(car);

                                        context
                                            .read<Cars>()
                                            .favoriteCars
                                            .forEach((element) {});
                                      }
                                    },
                                  ),
                                )
                                .toList(),
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  void onSearchChange(BuildContext context) {
    context.read<Cars>().filter(searchController.text);
  }
}
