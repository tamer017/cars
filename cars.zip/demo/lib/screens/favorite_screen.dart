import 'package:demo/providers/cars.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'car_card.dart';
import 'car_info.dart';
import '../local_storge.dart';

class FavoriteScreen extends StatefulWidget {
  @override
  _FavoriteScreenState createState() => _FavoriteScreenState();
}

class _FavoriteScreenState extends State<FavoriteScreen> {
  @override
  Widget build(BuildContext context) {
    double heightBlock = MediaQuery.of(context).size.height / 100;
    double widthBlock = MediaQuery.of(context).size.width / 100;
    

    return ChangeNotifierProvider<Cars>(
      create: (_) => Cars(),
      child: !context.read<Cars>().favoriteCars.isEmpty
          ? GridView(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisExtent: heightBlock * 35,
                crossAxisSpacing: 0,
                mainAxisSpacing: 0,
              ),
              children: context
                  .read<Cars>()
                  .favoriteCars
                  .map(
                    (car) => GestureDetector(
                      child: Container(
                        margin: EdgeInsets.only(
                          left: 0,
                          right: 0,
                          top: context
                                  .read<Cars>()
                                  .favoriteCars
                                  .indexOf(car)
                                  .isEven
                              ? 0
                              : heightBlock * 2.5,
                          bottom: context
                                  .read<Cars>()
                                  .favoriteCars
                                  .indexOf(car)
                                  .isOdd
                              ? 0
                              : heightBlock * 2.5,
                        ),
                        child: CarCard(
                          name: car.model,
                          price: car.price.toString(),
                          index: context.read<Cars>().cars.indexOf(car),
                          isFavorite: true,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      onTap: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (ctx) => CarInfo()));
                      },
                      onDoubleTap: () {
                        setState(() {
                          context.read<Cars>().deleteFav(car);
                        });
                      },
                    ),
                  )
                  .toList(),
            )
          : Center(
              child: Text(
                "you have no favorite Cars",
                style: TextStyle(
                    color: Theme.of(context).primaryColor,
                    fontSize: heightBlock * 4,
                    fontWeight: FontWeight.w900),
              ),
            ),
    );
  }
}
// Container(
//             height: heightBlock * 77.5,
//             child: context.read<Cars>().favoriteCars.isEmpty
//                 ? Center(
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text(
//                           "No Cars to show",
//                           style: TextStyle(
//                               color: Theme.of(context).primaryColor,
//                               fontSize: heightBlock * 5,
//                               fontWeight: FontWeight.w900),
//                         ),
//                         TextButton.icon(
//                           onPressed: () {
//                             setState(() {
//                               context.read<Cars>().setFavlist(Car.favCars);
//                             });
//                           },
//                           icon: Icon(Icons.replay_outlined),
//                           label: Text("click  here to refresh"),
//                         ),
//                       ],
//                     ),
//                   )
//                 : RefreshIndicator(
//                     onRefresh: () async =>
//                         await context.read<Cars>().setFavlist(Car.favCars),
//                     child: GridView(
//                       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                         crossAxisCount: 2,
//                         mainAxisExtent: heightBlock * 35,
//                         crossAxisSpacing: 0,
//                         mainAxisSpacing: 0,
//                       ),
//                       children: context
//                           .read<Cars>()
//                           .favoriteCars
//                           .map(
//                             (car) => CarCard(
//                               name: car.model,
//                               price: car.price.toString(),
//                               index: context.read<Cars>().cars.indexOf(car),
//                               isFavorite: true,
//                               color: Theme.of(context).primaryColor,
//                             ),
//                           )
//                           .toList(),
//                     ),
//                   ),
//           ),


