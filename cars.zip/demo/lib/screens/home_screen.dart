import 'package:demo/providers/cars.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'add_car.dart';
import 'cars_screen.dart';
import 'favorite_screen.dart';
import 'my_drawer.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    double heightBlock = MediaQuery.of(context).size.height / 100;
    double widthBlock = MediaQuery.of(context).size.width / 100;
    return Scaffold(
      appBar: AppBar(
        title: Text("api demo"),
        actions: [
          _currentIndex == 0
              ? TextButton.icon(
                  onPressed: () {
                    if (!context.read<Cars>().isSelected)
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => AddCar(),
                        ),
                      );
                  },
                  icon: Icon(
                    Icons.add,
                    color: Colors.white,
                  ),
                  label: Text(
                    "add Car",
                    style: TextStyle(color: Colors.white),
                  ),
                )
              : const Text("")
        ],
      ),
      body: screens.elementAt(_currentIndex),
      drawer: MyDrawer(),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await context.read<Cars>().getFromApi();
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Theme.of(context).primaryColor,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.black,
        currentIndex: _currentIndex,
        selectedFontSize: heightBlock * 2.5,
        unselectedFontSize: heightBlock * 1.5,
        onTap: selectScreen,
        items: [
          const BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          const BottomNavigationBarItem(
              icon: Icon(Icons.favorite), label: "Favorite"),
        ],
      ),
    );
  }

  List<Widget> screens = [CarsScreen(), FavoriteScreen()];
  int _currentIndex = 0;
  selectScreen(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
}
