import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/cars.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double heightBlock = MediaQuery.of(context).size.height / 100;
    double widthBlock = MediaQuery.of(context).size.width / 100;
    return ChangeNotifierProvider(
      create: (_) => Cars(),
      child: Drawer(
        child: Scaffold(
          // appBar: AppBar(
          //   title: Text("data"),
          //   actions: [Container()],
          // ),
          body: Column(
            children: [
              Container(
                alignment: Alignment.center,
                padding: EdgeInsets.only(top: heightBlock * 2),
                color: Theme.of(context).primaryColor,
                height: heightBlock * 12.5,
                child: ListTile(
                  title: Text(
                    "settings",
                    style: TextStyle(
                        fontSize: widthBlock * 8, fontWeight: FontWeight.w700),
                  ),
                  leading: Icon(
                    Icons.settings,
                    size: widthBlock * 6,
                    color: Colors.black,
                  ),
                ),
              ),
              DropdownButton<Color>(
                items: <Color>[
                  Colors.yellow,
                  Colors.blue,
                  Colors.green,
                ].map((Color value) {
                  return DropdownMenuItem<Color>(
                    value: value,
                    child: CircleAvatar(
                      backgroundColor: value,
                    ),
                  );
                }).toList(),
                hint: Text(
                  "chosse the theme",
                  style: TextStyle(fontSize: heightBlock * 3),
                ),
                onChanged: (color) {
                  if (color == Colors.green) {
                    context.read<Cars>().setTheme(0);
                  } else if (color == Colors.yellow) {
                    context.read<Cars>().setTheme(1);
                  } else if (color == Colors.blue) {
                    context.read<Cars>().setTheme(2);
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
